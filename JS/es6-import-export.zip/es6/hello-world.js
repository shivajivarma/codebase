const helloWorld = () => alert ('Hello World!');
export {
    helloWorld
};